library(RODBC)

db <- "C:/Users/PavleiMila/Documents/NovameteoroloskiPodaci.accdb"
con <- odbcConnectAccess2007(db)

sqlTables(con, tableType = "DATA")

data <- sqlFetch(con, "DATA")
str(data)
qry <- "SELECT * FROM DATA"
class <- sqlQuery(con, qry)
str(class)
head(class)
odbcCloseAll()
