# Vizuelizacija podataka
library(tidyverse)
library(openair)
library(leaflet)
install.packages("lubridate")
library(dplyr)
library(shiny)
library(xts)
# air 17.csv je rename od Podaci iz ZIP-a profesora
podaci =read.csv("air 17.csv")
#air.17 =read.csv("air 17.csv")
stanice = read.csv("station.csv", sep=";", stringsAsFactors= FALSE,header = TRUE, encoding="UTF-8")
names(stanice)[1] = "station_id"
utils:::menuInstallPkgs()
utils:::menuInstallPkgs()
utils:::menuInstallPkgs()
utils:::menuInstallPkgs()
utils:::menuInstallPkgs()
# Vizuelizacija podataka
library(tidyverse)
library(openair)
library(leaflet)
install.packages("lubridate")
library(dplyr)
library(shiny)
library(xts)
# air 17.csv je rename od Podaci iz ZIP-a profesora
podaci =read.csv("air 17.csv")
#air.17 =read.csv("air 17.csv")
stanice = read.csv("station.csv", sep=";", stringsAsFactors= FALSE,header = TRUE, encoding="UTF-8")
names(stanice)[1] = "station_id"
podaci = merge(podaci, stanice,by= "station_id")
id = unique(podaci$station_id)
latitude = unique(podaci$latitude)
longitude = unique(podaci$longitude)
naziv = unique(podaci$k_name)
stanice1 = data.frame(id, naziv, longitude, latitude)
head(stanice1)
  id             naziv longitude latitude
1  1    Kikinda Centar  20.45401 45.82148
2  2    Novi Sad SPENS  19.84119 45.24506
3  3    Novi Sad Liman  19.83570 45.23864
4  4     Beocin Centar  19.72171 45.20839
5  5 Sremska Mitrovica  19.60935 44.97219
6  6    Pancevo Sodara  20.64429 44.86297
stanice1$lat <- as.numeric(as.character(stanice1$latitude))
stanice1$lon <- as.numeric(as.character(stanice1$longitude))
lon <- max(stanice1$longitude) 
lat <- max(stanice1$latitude) 
m = leaflet(stanice1) %>% 
+ addTiles() %>% 
+ setView(lon, lat, zoom = 1)
m %>% 
+   addMarkers(data = stanice1, lng = ~longitude, lat = ~latitude,
+   icon = list(
+     iconUrl = 'http://icons.iconarchive.com/icons/artua/star-wars/128/Master-Joda-icon.png',
+     iconSize = c(75, 75)
utils:::menuInstallPkgs()
+    ))
# Vizuelizacija podataka
library(tidyverse)
library(openair)
library(leaflet)
install.packages("lubridate")
library(dplyr)
library(shiny)
library(xts)
# air 17.csv je rename od Podaci iz ZIP-a profesora
podaci =read.csv("air 17.csv")
#air.17 =read.csv("air 17.csv")
stanice = read.csv("station.csv", sep=";", stringsAsFactors= FALSE,header = TRUE, encoding="UTF-8")
names(stanice)[1] = "station_id"
podaci = merge(podaci, stanice,by= "station_id")
id = unique(podaci$station_id)
latitude = unique(podaci$latitude)
longitude = unique(podaci$longitude)
naziv = unique(podaci$k_name)
stanice1 = data.frame(id, naziv, longitude, latitude)
head(stanice1)
stanice1$lat <- as.numeric(as.character(stanice1$latitude))
stanice1$lon <- as.numeric(as.character(stanice1$longitude))
lon <- max(stanice1$longitude) 
lat <- max(stanice1$latitude) 
m = leaflet(stanice1) %>% 
 addTiles() %>% 
 setView(lon, lat, zoom = 1)
m %>% 
   addMarkers(data = stanice1, lng = ~longitude, lat = ~latitude,
   icon = list(
     iconUrl = 'http://icons.iconarchive.com/icons/artua/star-wars/128/Master-Joda-icon.png',
     iconSize = c(75, 75)
    ))
install.packages('vctrs')
install.packages("rlang")
install.packages("sqldf")
install.packages("RSQLite")
install.packages("ggplot2")
maksco = aggregate(podaci$co ~podaci$station_id, podaci, max)
library(vctrs)
library(sqldf)
library(RSQLite)
maks.co.po.stanicama = sqldf(
 'SELECT id, naziv, longitude,latitude, podaci$co AS co
  FROM stanice JOIN maksco
  ON id=podaci$station_id')
m = leaflet() %>%
 addTiles() %>%
addMarkers(lng=maks.co.po.stanicama$longitude,
lat=maks.co.po.stanicama$latitude,
popup=as.character(paste("CO:",maks.co.po.stanicama$co)))
m # prikaz mape
boja <- function(tabela) {
 sapply(tabela$co, function(co) {
 if(co <= 5) {
 "green"
 } else if(co <= 10) {
 "orange"
 } else {
 "red"
 } })
}
icons <- awesomeIcons(
 icon = 'ios-close',
 iconColor = 'black',
 library = 'ion',
 markerColor = boja(maks.co.po.stanicama)
)
leaflet(maks.co.po.stanicama) %>% addTiles() %>%
 addAwesomeMarkers(~longitude, ~latitude,
icon=icons, label=~as.character(paste("CO:",co)))
barplot(maks.co.po.stanicama$co,
 main = "Nivo CO",
 xlab = "stanice",
 ylab =
"Nivo"
,
 ylim = c(0,120),
 names.arg = maks.co.po.stanicama$naziv,
 border = "blue",
 col = "red")
dan = subset(cacak, subset = cacak$date == "2019-03-01")
library(ggplot2)
ggplot(dan, aes(x = time, y = Vrednost, color =
Parametar)) +
 geom_point(aes(y = no2, col="no2"),size = 5) +
 geom_point(aes(y = nox, col="nox"),size = 5) +
 geom_point(aes(y = no, col="no"),size = 5) +
 geom_point(aes(y = co, col="co"),size = 5) +
 labs(title = "Ekoloski pokazatelji za Cacak",
 x = "Datum i vreme")
maks.co.po.stanicama = sqldf(
 'SELECT station_id, naziv, longitude,latitude, podaci$co AS co
  FROM stanice JOIN maksco
  ON id=podaci$station_id')
m = leaflet() %>%
 addTiles() %>%
addMarkers(lng=maks.co.po.stanicama$longitude,
lat=maks.co.po.stanicama$latitude,
popup=as.character(paste("CO:",maks.co.po.stanicama$co)))
m # prikaz mape
boja <- function(tabela) {
 sapply(tabela$co, function(co) {
 if(co <= 5) {
 "green"
 } else if(co <= 10) {
 "orange"
 } else {
 "red"
 } })
}
icons <- awesomeIcons(
 icon = 'ios-close',
 iconColor = 'black',
 library = 'ion',
 markerColor = boja(maks.co.po.stanicama)
)
leaflet(maks.co.po.stanicama) %>% addTiles() %>%
 addAwesomeMarkers(~longitude, ~latitude,
icon=icons, label=~as.character(paste("CO:",co)))
barplot(maks.co.po.stanicama$co,
 main = "Nivo CO",
 xlab = "stanice",
 ylab =
"Nivo"
,
 ylim = c(0,120),
 names.arg = maks.co.po.stanicama$naziv,
 border = "blue",
 col = "red")
dan = subset(cacak, subset = cacak$date == "2019-03-01")
library(ggplot2)
ggplot(dan, aes(x = time, y = Vrednost, color =
Parametar)) +
 geom_point(aes(y = no2, col="no2"),size = 5) +
 geom_point(aes(y = nox, col="nox"),size = 5) +
 geom_point(aes(y = no, col="no"),size = 5) +
 geom_point(aes(y = co, col="co"),size = 5) +
 labs(title = "Ekoloski pokazatelji za Cacak",
 x = "Datum i vreme")
maks.co.po.stanicama = sqldf(
 'SELECT station_id, naziv, longitude,latitude, podaci$co AS co
  FROM stanice1 JOIN maksco
  ON id=podaci$station_id')
str(stanice)
maks.co.po.stanicama = sqldf(
 'SELECT station_id, k_name, longitude, latitude, podaci$co AS co
  FROM stanice JOIN maksco
  ON id=podaci$station_id')
maks.co.po.stanicama = sqldf(
 'SELECT station_id, k_name, longitude, latitude, podaci$co AS co
  FROM stanice JOIN maksco
  ON station_id=podaci$station_id')
m = leaflet() %>%
 addTiles() %>%
addMarkers(lng=maks.co.po.stanicama$longitude,
lat=maks.co.po.stanicama$latitude,
popup=as.character(paste("CO:",maks.co.po.stanicama$co)))
m # prikaz mape
boja <- function(tabela) {
 sapply(tabela$co, function(co) {
 if(co <= 5) {
 "green"
 } else if(co <= 10) {
 "orange"
 } else {
 "red"
 } })
}
icons <- awesomeIcons(
 icon = 'ios-close',
 iconColor = 'black',
 library = 'ion',
 markerColor = boja(maks.co.po.stanicama)
)
leaflet(maks.co.po.stanicama) %>% addTiles() %>%
 addAwesomeMarkers(~longitude, ~latitude,
icon=icons, label=~as.character(paste("CO:",co)))
barplot(maks.co.po.stanicama$co,
 main = "Nivo CO",
 xlab = "stanice",
 ylab =
"Nivo"
,
 ylim = c(0,120),
 names.arg = maks.co.po.stanicama$naziv,
 border = "blue",
 col = "red")
dan = subset(cacak, subset = cacak$date == "2019-03-01")
library(ggplot2)
ggplot(dan, aes(x = time, y = Vrednost, color =
Parametar)) +
 geom_point(aes(y = no2, col="no2"),size = 5) +
 geom_point(aes(y = nox, col="nox"),size = 5) +
 geom_point(aes(y = no, col="no"),size = 5) +
 geom_point(aes(y = co, col="co"),size = 5) +
 labs(title = "Ekoloski pokazatelji za Cacak",
 x = "Datum i vreme")
ggsave("grafik.png")
save.image("C:\\Users\\Korisnik\\Documents\\Vizualizacija i SQL prikaz hidroloskih stanica")
