
# Vizuelizacija podataka
library(tidyverse)
library(openair)
library(leaflet)
install.packages("lubridate")
library(dplyr)
library(shiny)
library(xts)

# air 17.csv je rename od Podaci
podaci =read.csv("air 17.csv")

stanice = read.csv("station.csv", sep=";", stringsAsFactors= FALSE,header = TRUE, encoding="UTF-8")
names(stanice)[1] = "station_id"
podaci = merge(podaci, stanice,by= "station_id")

id = unique(podaci$station_id)
latitude = unique(podaci$latitude)
longitude = unique(podaci$longitude)
naziv = unique(podaci$k_name)

stanice1 = data.frame(id, naziv, longitude, latitude)

head(stanice1)
  id             naziv longitude latitude
1  1    Kikinda Centar  20.45401 45.82148
2  2    Novi Sad SPENS  19.84119 45.24506
3  3    Novi Sad Liman  19.83570 45.23864
4  4     Beocin Centar  19.72171 45.20839
5  5 Sremska Mitrovica  19.60935 44.97219
6  6    Pancevo Sodara  20.64429 44.86297

stanice1$lat <- as.numeric(as.character(stanice1$latitude))
stanice1$lon <- as.numeric(as.character(stanice1$longitude))
lon <- max(stanice1$longitude) 
lat <- max(stanice1$latitude) 

m = leaflet(stanice1) %>% 
 addTiles() %>% 
 setView(lon, lat, zoom = 1)
m %>% 
   addMarkers(data = stanice1, lng = ~longitude, lat = ~latitude,
   icon = list(
     iconUrl = 'https://icons.iconarchive.com/icons/icons-land/vista-map-markers/48/Map-Marker-Marker-Outside-Azure-icon.png',
     iconSize = c(40, 40)))

install.packages('vctrs')
install.packages("rlang")
install.packages("sqldf")
install.packages("RSQLite")
install.packages("ggplot2")

maksco = aggregate(podaci$co ~podaci$station_id, podaci, max)

library(vctrs)
library(sqldf)
library(RSQLite)

maks.co.po.stanicama = sqldf(
 'SELECT id, naziv, longitude,latitude, podaci$co AS co
  FROM stanice1 JOIN maksco
  ON id=podaci$station_id')
m = leaflet() %>%
 addTiles() %>%
addMarkers(lng=maks.co.po.stanicama$longitude,
lat=maks.co.po.stanicama$latitude,
popup=as.character(paste("CO:",maks.co.po.stanicama$co)))
m # prikaz mape

boja <- function(tabela) {
 sapply(tabela$co, function(co) {
 if(co <= 5) {
 "green"
 } else if(co <= 10) {
 "orange"
 } else {
 "red"
 } })
}

icons <- awesomeIcons(
 icon = 'ios-close',
 iconColor = 'black',
 library = 'ion',
 markerColor = boja(maks.co.po.stanicama)
)

leaflet(maks.co.po.stanicama) %>% addTiles() %>%
 addAwesomeMarkers(~longitude, ~latitude,
icon=icons, label=~as.character(paste("CO:",co)))
barplot(maks.co.po.stanicama$co,
 main = "Nivo CO",
 xlab = "stanice",
 ylab ="Nivo",
 ylim = c(0,120),
 names.arg = maks.co.po.stanicama$naziv,
 border = "blue",
 col = "red")

cacak= podaci %>% filter(station_id== 31)
#################################################################
cacak.Data= cacak%>% spread(key = station_id, value = c["date_time","station_id","so2"
,"pm10","o3","no2","nox","co","benzene","toluene","no","pm2_5","pm1","wind_velocity"
,"wind_direction","pressure","temp","humidity"])

cacak.Data= cacak%>% spread(key = station_id, value = c["station_id","date_time","so2","pm10","o3","no2","nox","co","benzene","toluene","no","pm2_5"
,"pm1","wind_velocity","wind_direction","pressure","temp","humidity","k_eoi_code",
"k_airbase_code","k_network_id","k_local_code","k_name","k_start_date","k_stop_date",
"latitude","longitude","aq_stationclassification","aq_areaclassification","k_char_of_zone",
"k_ozone_classification","k_main_emission_source","k_city","k_city_population",
"k_street_name","k_report"])

cacak.Data= cacak%>% spread(key = station_id, value = co)
cacak.Data= cacak%>% spread(key = station_id, value = c(date,so2,pm10,o3,no2,nox,co,benzene,toluene,no,pm2_5
,pm1,wind_velocity,wind_direction,pressure,temp,humidity,k_eoi_code,
k_airbase_code,k_network_id,k_local_code,k_name,k_start_date,k_stop_date,
latitude,longitude,aq_stationclassification,aq_areaclassification,k_char_of_zone,
k_ozone_classification,k_main_emission_source,k_city,k_city_population,
k_street_name,k_report))

cacak.Data= cacak%>% spread(key = station_id, value = date,so2,no2,nox,co,no)


cacak= podaci %>% filter(station_id== 31)
colnames(cacak) = c("date","station_id","SO2","NO2","NOx","CO","NO","P","t","RH")
cacak$date= as.POSIXct(cacak$date, format = "%Y-%m-%d %H:%M:%S")
summary(cacak)

#############################
colnames(cacak.Data) = c("date","station_id","SO2","NO2","NOx","CO","NO","P","t","RH")
cacak.Data$date= as.POSIXct(cacak.Data$date, format = "%Y-%m-%d %H:%M:%S")
summary(cacak.Data)

dan = subset(cacak, subset = cacak$date == "2019-03-01")

library(ggplot2)

ggplot(dan, aes(x = time, y = Vrednost, color =
Parametar)) +
 geom_point(aes(y = no2, col="NO2"),size = 5) +
 geom_point(aes(y = nox, col="NOx"),size = 5) +
 geom_point(aes(y = no, col="NO"),size = 5) +
 geom_point(aes(y = no, col="CO"),size = 5) +
 labs(title = "Ekoloski pokazatelji za Cacak",
 x = "Datum i vreme")

ggplot(dan, aes(x = time, y = Vrednost, color =
Parametar)) +
 geom_point(aes(y = NO, col="NO"),size = 5) +
 labs(title = "Ekoloski pokazatelji za Cacak",
 x = "Datum i vreme")

maks.co.po.stanicama = sqldf(
 'SELECT station_id, naziv, longitude,latitude, podaci$co AS co
  FROM stanice1 JOIN maksco
  ON id=podaci$station_id')
m = leaflet() %>%
 addTiles() %>%
addMarkers(lng=maks.co.po.stanicama$longitude,
lat=maks.co.po.stanicama$latitude,
popup=as.character(paste("CO:",maks.co.po.stanicama$co)))
m # prikaz mape

boja <- function(tabela) {
 sapply(tabela$co, function(co) {
 if(co <= 5) {
 "green"
 } else if(co <= 10) {
 "orange"
 } else {
 "red"
 } })
}

icons <- awesomeIcons(
 icon = 'ios-close',
 iconColor = 'black',
 library = 'ion',
 markerColor = boja(maks.co.po.stanicama)
)

leaflet(maks.co.po.stanicama) %>% addTiles() %>%
 addAwesomeMarkers(~longitude, ~latitude,
icon=icons, label=~as.character(paste("CO:",co)))
barplot(maks.co.po.stanicama$co,
 main = "Nivo CO",
 xlab = "stanice",
 ylab =
"Nivo"
,
 ylim = c(0,120),
 names.arg = maks.co.po.stanicama$naziv,
 border = "blue",
 col = "red")

dan = subset(cacak, subset = cacak$date == "2019-03-01")

library(ggplot2)
library(knitr)
library(dplyr)
library(ggplot2)
library(ggmap)
library(ompr)
library(ompr.roi)
library(ROI.plugin.glpk)



ggplot(dan, aes(time, co, colour = class)) + 
  geom_point()



ggplot(dan, aes(x = time, y = Vrednost, color =
Parametar)) +
 geom_point(aes(y = NO2, col="NO2"),size = 5) +
 geom_point(aes(y = NOx, col="NOx"),size = 5) +
 geom_point(aes(y = NO, col="NO"),size = 5) +
 geom_point(aes(y = CO, col="CO"),size = 5) +
 labs(title = "Ekoloski pokazatelji za Cacak",
 x = "Datum i vreme")
####1
ggplot(data=dan, aes(x=Sample, y=value, fill=variable)) +
    geom_bar(width=1) +
    scale_y_continuous(expand = c(0,0)) +
    opts(axis.text.x=theme_text(angle=90))
####1



maks.co.po.stanicama = sqldf(
 'SELECT station_id, naziv, longitude,latitude, podaci$co AS co
  FROM stanice1 JOIN maksco
  ON id=podaci$station_id')
str(stanice)

maks.co.po.stanicama = sqldf(
 'SELECT station_id, k_name, longitude, latitude, podaci$co AS co
  FROM stanice JOIN maksco
  ON id=podaci$station_id')

maks.co.po.stanicama = sqldf(
 'SELECT station_id, k_name, longitude, latitude, podaci$co AS co
  FROM stanice JOIN maksco
  ON station_id=podaci$station_id')

m = leaflet() %>%
 addTiles() %>%
addMarkers(lng=maks.co.po.stanicama$longitude,
lat=maks.co.po.stanicama$latitude,
popup=as.character(paste("CO:",maks.co.po.stanicama$co)))
m # prikaz mape

boja <- function(tabela) {
 sapply(tabela$co, function(co) {
 if(co <= 5) {
 "green"
 } else if(co <= 10) {
 "orange"
 } else {
 "red"
 } })
}
icons <- awesomeIcons(
 icon = 'ios-close',
 iconColor = 'black',
 library = 'ion',
 markerColor = boja(maks.co.po.stanicama)
)

leaflet(maks.co.po.stanicama) %>% addTiles() %>%
 addAwesomeMarkers(~longitude, ~latitude,
icon=icons, label=~as.character(paste("CO:",co)))
barplot(maks.co.po.stanicama$co,
 main = "Nivo CO",
 xlab = "stanice",
 ylab =
"Nivo"
,
 ylim = c(0,120),
 names.arg = maks.co.po.stanicama$naziv,
 border = "blue",
 col = "red")

dan = subset(cacak, subset = cacak$date == "2019-03-01")

library(ggplot2)

ggplot(dan, aes(x = time, y = c(0,120), color =
Parametar)) +
 geom_point(aes(y = no2, col="no2"),size = 5) +
 geom_point(aes(y = nox, col="nox"),size = 5) +
 geom_point(aes(y = no, col="no"),size = 5) +
 geom_point(aes(y = co, col="co"),size = 5) +
 labs(title = "Ekoloski pokazatelji za Cacak",
 x = "Datum i vreme")

ggsave("grafik.png")
save.image("C:\\Users\\Korisnik\\Documents\\Vizualizacija i SQL prikaz hidroloskih stanica")
