﻿# neuralnets.R 
# R 3.2.4

#install.packages("arulesViz")
library(arulesViz) 
library(tensorflow)
library(ggplot2)
###
library(clusterGeneration)
library(nnet)
library(devtools)
seed.val<-2
set.seed(seed.val)

num.vars<-8
num.obs<-1000
###
NeuralNetwork = setRefClass( "NeuralNetwork", 
fields = list( ni = "integer", nh = "integer", no = "integer", inputs = "array", ihWeights = "matrix", hBiases = "array", hiddens = "array", hoWeights = "matrix", oBiases = "array", outputs = "array" ), 
methods = list(initialize = function(ni, nh, no) 
{ 
.self$ni <- ni 
.self$nh <- nh 
.self$no <- no 
inputs <<- array(0.0, ni) 
ihWeights <<- matrix(0.0, nrow=ni, ncol=nh) 
hBiases <<- array(0.0, nh) 
hiddens <<- array(0.0, nh) 
hoWeights <<- matrix(0.0, nrow=nh, ncol=no) 
oBiases <<- array(0.0, no) 
outputs <<- array(0.0, no) 
}, 
# initialize() 
setWeights = function(wts) { 
numWts <- (ni * nh) + nh + (nh * no) + no 
if (length(wts) != numWts) { 
stop("FATAL: incorrect number weights") } 
wi <- as.integer(1) 
# weight index 
for (i in 1:ni) { 
for (j in 1:nh) {
ihWeights[i,j] <<- wts[wi] 
wi <- wi + 1 
} 
} 
for (j in 1:nh) { 
hBiases[j] <<- wts[wi] 
wi <- wi + 1 
} 
for (j in 1:nh) { 
for (k in 1:no) { 
hoWeights[j,k] <<- wts[wi] 
wi <- wi + 1 
} 
} 
for (k in 1:no) { 
oBiases[k] <<- wts[wi] 
wi <- wi + 1 
} 
}, 
# setWeights() 
computeOutputs = function(xValues) { 
hSums <- array(0.0, nh) 
# hidden nodes scratch array 
oSums <- array(0.0, no) 
# output nodes scratch 
for (i in 1:ni) { 
inputs[i] <<- xValues[i] 
} 
for (j in 1:nh) { 
# pre-activation hidden node sums 
for (i in 1:ni) { 
hSums[j] <- hSums[j] + (inputs[i] * ihWeights[i,j]) 
} 
} 
for (j in 1:nh) { 
# add bias 
hSums[j] <- hSums[j] + hBiases[j] 
} 
for (j in 1:nh) { 
# apply activation 
hiddens[j] <<- tanh(hSums[j]) 
} 
for (k in 1:no) { 
# pre-activation output node sums 
for (j in 1:nh) { 
oSums[k] <- oSums[k] + (hiddens[j] * hoWeights[j,k]) 
} 
} 
for (k in 1:no) { 
# add bias 
oSums[k] <- oSums[k] + oBiases[k] 
} 
outputs <<- my_softMax(oSums) 
# apply activation 
return(outputs)
}, 
# computeOutputs() 
my_softMax = function(arr) { 
n = length(arr) 
result <- array(0.0, n) 
sum <- 0.0 
for (i in 1:n) { 
sum <- sum + exp(arr[i]) 
} 
for (i in 1:n) { 
result[i] <- exp(arr[i]) / sum 
} 
return(result) 
} 
)
 
# methods 
) 

# class # ----- 
cat("\nBegin neural network demo \n") 
numInput <- as.integer(3) 
numHidden <- as.integer(4) 
numOutput <- as.integer(2) 
cat("\nSetting numInput = ", numInput, "\n") 
cat("Setting numHidden = ", numHidden, "\n") 
cat("Setting numOutput = ", numOutput, "\n") 
cat("\nCreating neural network \n") 

nn <- NeuralNetwork$new(numInput, numHidden, numOutput) 

cat("\nSetting input-hidden weights to 0.01 to 0.12 \n") 
cat("Setting hidden biases to 0.13 to 0.16 \n") 
cat("Setting hidden-output weights to 0.17 to 0.24 \n") 
cat("Setting output biases to 0.25 to 0.26 \n") 
wts <- seq(0.01, 0.26, by=0.01) 

nn$setWeights(wts) 
xValues <- c(1.0, 2.0, 3.0) 
cat("\nSetting input values: ") 
print(xValues) 
cat("\nComputing output values \n") 
outputs <- nn$computeOutputs(xValues) 
cat("\nDone \n") 
cat("\nOutput values: ") 
print(outputs) 
cat("\nEnd demo\n")
###
#nnet function from nnet package
set.seed(seed.val)
#mod1<-nnet(rand.vars,resp,data=dat.in,size=10,linout=T)

#import the function from Github
source_url('https://gist.githubusercontent.com/Peque/41a9e20d6687f2f3108d/raw/85e14f3a292e126f1454864427e3a189c2fe33f3/nnet_plot_update.r')

#plot each model
###
nn<-nnet(numInput,numHidden,size=10,linout=T)
require(nnet)
plotnet(nn)
plotnet(nn,pos.col='darkgreen',neg.col='darkblue',alpha.val=0.7,rel.rsc=15,circle.cex=10,cex=1.4,circle.col='brown')

pdf('./nn-example.pdf', width = 7, height = 7)
plot.nnet(nn, alpha.val = 0.5, circle.col = list('lightgray', 'white'), bord.col = 'black')
dev.off()

#######################################################################################
library(NeuralNetTools)
# plotnet(nn)
plotnet(nn)

#plotnet(nn,pos.col='darkgreen',neg.col='darkblue',alpha.val=0.7,rel.rsc=15,circle.cex=10,cex=1.4,circle.col='brown')
plot(nn,pos.col='darkgreen',neg.col='darkblue',alpha.val=0.7,rel.rsc=15,circle.cex=10,cex=1.4,circle.col='brown')

###
nn<-nnet(numInput,numHidden,size=10,linout=T)
require(nnet)
plot.nnet(nn)
###
par(mar=numeric(4),mfrow=c(1,2),family='serif')
plot(nn,nid=F)
plot(nn)
###
plot.nnet(nn,pos.col='darkgreen',neg.col='darkblue',alpha.val=0.7,rel.rsc=15,
circle.cex=10,cex=1.4,
    circle.col='brown')

#####
# Primer beckmw.wp
require(clusterGeneration)
 
set.seed(2)
num.vars<-8
num.obs<-1000
 
#arbitrary correlation matrix and random variables
cov.mat<-genPositiveDefMat(num.vars,covMethod=c("unifcorrmat"))$Sigma
rand.vars<-mvrnorm(num.obs,rep(0,num.vars),Sigma=cov.mat)
parms<-runif(num.vars,-10,10)
 
#response variable as linear combination of random variables and random error term
y<-rand.vars %*% matrix(parms) + rnorm(num.obs,sd=20)

require(nnet)
 
rand.vars<-data.frame(rand.vars)
y<-data.frame((y-min(y))/(max(y)-min(y)))
names(y)<-'y'
 
mod1<-nnet(rand.vars,y,size=10,linout=T)

#import function from Github
require(RCurl)
 
root.url<-'https://gist.githubusercontent.com/fawda123'
raw.fun<-paste(
  root.url,
  '5086859/raw/cc1544804d5027d82b70e74b83b3941cd2184354/nnet_plot_fun.r',
  sep='/'
  )
script<-getURL(raw.fun, ssl.verifypeer = FALSE)
eval(parse(text = script))
rm('script','raw.fun')

par(mar=numeric(4),mfrow=c(1,2),family='serif')
plot(mod1,nid=F)
plot(mod1)

#example data and code from nnet function examples
ir<-rbind(iris3[,,1],iris3[,,2],iris3[,,3])
targets<-class.ind( c(rep("s", 50), rep("c", 50), rep("v", 50)) )
samp<-c(sample(1:50,25), sample(51:100,25), sample(101:150,25))
ir1<-nnet(ir[samp,], targets[samp,], size = 2, rang = 0.1,decay = 5e-4, maxit = 200)
 
#plot the model with different default values for the arguments
par(mar=numeric(4),family='serif')
plot.nnet(ir1,pos.col='darkgreen',neg.col='darkblue',alpha.val=0.7,rel.rsc=15,
circle.cex=10,cex=1.4,
    circle.col='brown')

plot.nnet(ir1,wts.only=T)
#####

###
	
#if (!isGeneric("plot")) 
#      setGeneric("plot", plot(nn), standardGeneric("plot")) 

#pdf('./nn-example.pdf', width = 7, height = 7)
#plot.nnet(nn, alpha.val = 0.5, circle.col = list('lightgray', 'white'), bord.col = 'black')
#dev.off()
#plot.nnet(nn)