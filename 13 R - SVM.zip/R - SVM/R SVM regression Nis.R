library(e1071)
library(rpart)

data<-read.csv("Nis.csv")

index <- 1:nrow(data)
testindex <- sample(index, trunc(length(index)/3))
testset <- data[testindex,]
trainset <- data[-testindex,]

svm.model <- svm(PMVPSH~., data = trainset, cost = 100, gamma =1)
svm.pred <- predict(svm.model, testset[,-10])

rpart.model <- rpart(PMVPSH~., data = trainset)
rpart.pred <- predict(rpart.model, testset[,-10])

head(table(pred = svm.pred, true = testset[,1]))

plot(data, pch=16)
model <- lm(PMVPSH ~ . , data)
predictedY <- predict(model, data)
points(data, predictedY, col = "blue", pch=4)

points(data$TSR, predictedY, col = "blue", pch=4)
plot(data, pch=16)
points(data$TSR, predictedY, col = "blue", pch=4)
rmse <- function(error)
{
  sqrt(mean(error^2))
}
 
error <- model$residuals  # same as data$Y - predictedY
predictionRMSE <- rmse(error)
model <- svm(PMVPSH ~ . , data)
predictedY <- predict(model, data)

points(data$TSR, predictedY, col = "red", pch=4)

model <- svm(PMVPSH ~ TSR, data)
predictedY <- predict(model, data)
points(data$TSR, predictedY, col = "red", pch=4)
tuneResult <- tune(svm, PMVPSH ~ .,  data = data,ranges = list(epsilon = seq(0,1,0.1), cost = 2^(2:9)))
print(tuneResult)



# Draw the tuning graph
plot(tuneResult)
tuneResult <- tune(svm, PMVPSH ~ .,  data = data,ranges = list(epsilon = seq(0,0.2,0.01), cost = 2^(2:9)))
print(tuneResult)

 

plot(tuneResult)
tunedModel <- tuneResult$best.model
tunedModelY <- predict(tunedModel, data) 
 
error <- data$Y - tunedModelY  
 
# this value can be different on your computer
# because the tune method  randomly shuffles the data
tunedModelRMSE <- rmse(error)

print(tunedModelRMSE)
#[1] NaN
print(tunedModelY)



plot(data$PMVPSH, pch=16)
points(data$PMVPSH, predictedY, col = "red", pch=4)



plot(data, pch=16)
points(data$TSR, predictedY, col = "red", pch=4)
plot(data$TSR, pch=16)
points(data$TSR, predictedY, col = "red", pch=4)
  lines(data$TSR, tunedModelY, col = "blue", pch=4)
plot(data$VP, pch=16)
points(data$VP, predictedY, col = "red", pch=4)
  lines(data$VP, tunedModelY, col = "blue", pch=4)
plot(data$SUNSHINE_HOURS, pch=16)
points(data$SUNSHINE_HOURS, predictedY, col = "red", pch=4)
  lines(data$SUNSHINE_HOURS, tunedModelY, col = "blue", pch=4)
plot(data$WIND_SPEED, pch=16)
points(data$WIND_SPEED, predictedY, col = "red", pch=4)
  lines(data$WIND_SPEED, tunedModelY, col = "blue", pch=4)  

  lines(data$WIND_SPEED, tunedModelY, col = "blue", pch=4)
 print(tunedModel)



 print(tunedModelRMSE)
#[1] NaN
