# R Succinctly
# sample_9_1.R
# Multiple regression

# LOAD DATA
#require("datasets")  # Load datasets package
#data(USJudgeRatings)  # Load data into workspace
#USJudgeRatings[1:3, 1:8]  # Display 8 variables for 3 cases
Data2 <- read.table(file="Nis.csv", sep=",", header=T)
attach(Data2)
summary(Data2)


# MULTIPLE REGRESSION: DEFAULT
# Simultaneous entry
# Save regression model to object
reg1 <- lm(PMVPSH ~ TSR+VP+SUNSHINE_HOURS+WIND_SPEED, data = Data2)
reg1  # Gives the coefficients only
summary(reg1)  # Gives variety of statistics

# MULTIPLE REGRESSION: STEPWISE: BACKWARDS REMOVAL
reg1 <- lm(PMVPSH ~ TSR+VP+SUNSHINE_HOURS+WIND_SPEED, data = Data2)
regb <- step(reg1,  # Stepwise regression, starts with full model
             direction = "backward",  # Backwards removal
             trace = 0)  # Don't print the steps
summary(regb)  # Give hypothesis testing info

# MULTIPLE REGRESSION: STEPWISE: FORWARDS SELECTION
# Start with model that has nothing but a constant
reg0 <- lm(PMVPSH ~ 1, data = Data2)  # Intercept only
regf <- step(reg0,  # Start with intercept only
             direction = "forward",  # Forward addition
             # scape is list of possible variables to include
             scope = (~ TSR+VP+SUNSHINE_HOURS+WIND_SPEED),
             data = Data2,
             trace = 0)  # Don't print the steps
summary(regf)  # Statistics on model

# CLEAN UP
detach("package:datasets", unload = TRUE)  # Unloads datasets package
rm(list = ls())  # Remove all objects from workspace