require(ggplot2)
require(foreign)
require(nnet)
require(reshape2)
require(caret)
require(kernlab)
require(polynom)

epl2013 <- read.csv("2013.csv")
epl2012 <- read.csv("2012.csv")
epl2011 <- read.csv("2011.csv")
epl2010 <- read.csv("2010.csv")

homeCols <- c("FTHG","HST","HC")
awayCols <- c("FTAG","AST","AC")
featureCols <- c("g","st","c","gradg","gradst","gradc","W")

selectStats <- function(x, team){
  homeTeam <- x[["HomeTeam"]]
  awayTeam <- x[["AwayTeam"]]
  if (team == homeTeam)
     as.numeric(x[homeCols])
  else
     as.numeric(x[awayCols])
}
weightedSum <- function (x, lambda=0.8){
  poly = polynomial(rev(x))
  predict(poly,lambda)
}
makeFeatures <- function(x, df, k=3, lambda=0.8){
  homeTeam <- x[["HomeTeam"]]
  awayTeam <- x[["AwayTeam"]]
  num <- as.numeric(x[["num"]])
  winner<-x[["FTR"]]
  lastkH <- tail(df[(df$HomeTeam==homeTeam | df$AwayTeam==homeTeam) & df$num<num, ],k)
  if (nrow(lastkH) == k)
  {
    statsH <- apply(lastkH,1,selectStats,team = homeTeam)
    #print(statsH)
    gradStatsH <- apply(t(statsH),2,convolve, type = "filter", y = c(1,-1))
    #print(t(gradStatsH))
    #print(apply(statsH,1,weightedSum, lambda=lambda))
    #print(apply(t(gradStatsH),1,weightedSum, lambda=lambda))
    featuresH <- c(apply(statsH,1,weightedSum, lambda=lambda), apply(t(gradStatsH),1,weightedSum, lambda=lambda))
    #print(featuresH)
    lastkA <- tail(df[(df$HomeTeam==awayTeam | df$AwayTeam==awayTeam) & df$num<num, ],k)
    if (nrow(lastkA) == k)
    {
      statsA <- apply(lastkA,1,selectStats,team = awayTeam)
      gradStatsA <- apply(t(statsA),2,convolve, type = "filter", y = c(1,-1))
      featuresA <- c(apply(statsA,1,weightedSum, lambda=lambda), apply(t(gradStatsA),1,weightedSum, lambda=lambda))
      features = c(featuresH-featuresA, winner)
      names(features) <- featureCols
      features
    }
  }
}
k = 11
lambda = 0.9

features2010<-apply(epl2010,1,makeFeatures, df = epl2010, k=k, lambda = lambda)
features2010<-Filter(Negate(is.null), features2010)
features2011<-apply(epl2011,1,makeFeatures, df = epl2011, k=k, lambda = lambda)
features2011<-Filter(Negate(is.null), features2011)
features2012<-apply(epl2012,1,makeFeatures, df = epl2012, k=k, lambda = lambda)
features2012<-Filter(Negate(is.null), features2012)
features2013<-apply(epl2013,1,makeFeatures, df = epl2013, k=k, lambda = lambda)
features2013<-Filter(Negate(is.null), features2013)

traindf <- data.frame(do.call("rbind", c(features2010,features2011,features2012)))
testdf <- data.frame(do.call("rbind", features2013))

traindf <- transform(traindf, g = as.numeric(as.character(g)), st = as.numeric(as.character(st)), c = as.numeric(as.character(c)), gradg = as.numeric(as.character(gradg)), gradst = as.numeric(as.character(gradst)), gradc = as.numeric(as.character(gradc)))
testdf <- transform(testdf, g = as.numeric(as.character(g)), st = as.numeric(as.character(st)), c = as.numeric(as.character(c)), gradg = as.numeric(as.character(gradg)), gradst = as.numeric(as.character(gradst)), gradc = as.numeric(as.character(gradc)))

ggplot(traindf,aes(x=g, y=st, shape = W, colour = W)) + geom_point(size=3) +labs(shape="Winner", colour="Winner")
ggplot(traindf,aes(x=g, y=gradg, shape = W, colour = W)) + geom_point(size=3) + scale_size_area("Winner")




sigma = 0.08
C = 2

svp <- ksvm(W~.,data=traindf[,c("g","c","st","W")],type="C-svc", kernel='rbf',kpar=list(sigma=sigma),C=C,cross=3)
svpg <- ksvm(W~.,data=traindf,type="C-svc", kernel='rbf',kpar=list(sigma=sigma),C=C,cross=3)
mlr <- multinom(W ~ g + st + c + gradg + gradst + gradc, traindf)
mlrg <- multinom(W ~ g + st + c, traindf)

PW <- predict(svpg,testdf)

conf_mat  <- cbind(testdf, PredictedWin=PW)
conf_mat_tab <- table(conf_mat[,c("W","PredictedWin")])
confusionMatrix(conf_mat_tab)

PW <- predict(svp,testdf)

conf_mat  <- cbind(testdf, PredictedWin=PW)
conf_mat_tab <- table(conf_mat[,c("W","PredictedWin")])
confusionMatrix(conf_mat_tab)

PW <- predict(mlrg,testdf)

conf_mat  <- cbind(testdf, PredictedWin=PW)
conf_mat_tab <- table(conf_mat[,c("W","PredictedWin")])
confusionMatrix(conf_mat_tab)

PW <- predict(mlr,testdf)

conf_mat  <- cbind(testdf, PredictedWin=PW)
conf_mat_tab <- table(conf_mat[,c("W","PredictedWin")])
confusionMatrix(conf_mat_tab)
